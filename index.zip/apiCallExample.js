var apiCallExample = "<Enter the url for your API endpoint here>";

// You can add this file name to .gitignore to prevent the API endpoint url from being shown in your repo